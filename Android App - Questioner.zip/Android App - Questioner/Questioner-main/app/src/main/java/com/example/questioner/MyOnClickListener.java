package com.example.questioner;
public interface MyOnClickListener{
    void onClick(int position);
}
